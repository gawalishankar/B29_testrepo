package org.javaproject.example;

public class Client {

	public static void main(String[] args) {
		Operation op = new Operation();
		op.bookdata();
		op.displaydata();
	}

}
