package com.employemamnagement.transaction;

public class Client {
public static void main(String[] args) {
	byte a=10;
	int b;
	b=a;
	float c;
	c=a;
	
	float f=102.5f;
	int x;
	x=(int)f;
	System.out.println(b);
	System.out.println(c);
	System.out.println(x);
	
}
	
	
}
