package com.employemamnagement.transaction;

public class Demo {
	static
	{
		System.out.println("static block");
	}
	
	public static void main(String[] args) {
		System.out.println("main method");
		
	}

}
