package com.employemamnagement.transaction;

public class Test {

	public static void main(String[] args) {
		Student s1=new Student();
		//System.out.println(s1.id=102);
		s1.getdata(101, "nani", "CSE", "Hyd");
		s1.display();

	}

}
