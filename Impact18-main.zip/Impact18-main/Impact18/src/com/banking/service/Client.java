package com.banking.service;

public class Client {
	public static void main(String[] args) {
		System.out.println("hello java");
	}

}
