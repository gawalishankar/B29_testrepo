package com.example.demo;

public class Client {
	String str;
	public static void main(String[] args) {
		Client c1=new Client();
		System.out.println(c1.str);
		
	}

}
