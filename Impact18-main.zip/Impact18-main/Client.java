class Client
{
public static void main(String args)
{
System.out.println("main method");

}

public static void main(String [] args)
{
main("Akash");
System.out.println("Welcome Impact 18");
}

}

class Client1
{
public static void main()
{
System.out.println("main method");

}

public static void main(String [] args)
{
main();
System.out.println("Welcome ");
}

}












