class Impact1
{
 int a;
static int b=15;
public static void main(String[] args)
{int c=100;
Impact1 i1=new Impact1();
i1.a=50;
System.out.println(i1.a);
System.out.println(b=60);
System.out.println(c);
}


}