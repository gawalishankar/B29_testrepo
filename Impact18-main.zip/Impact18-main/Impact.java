class Impact
{
static int a=10;
public static void main(String [] args)
{
int a=20;
Impact i1=new 	Impact();
//System.out.println(i1.a);
System.out.println(a);
//System.out.println(i1.a);
System.out.println(Impact.a);
}



}

