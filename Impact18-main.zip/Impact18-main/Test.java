abstract class Demo extends  javafx.application.Application
{

static 
{
System.out.println("With out main method");
System.exit(0);
}


}
