class A
{

static int a=10;
static String str="Fuel";


}
class B
{

public static void main(String [] args)
{
System.out.println(A.a);
System.out.println(A.str);

}


}