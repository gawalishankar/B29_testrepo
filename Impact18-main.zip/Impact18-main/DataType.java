 class DataType{
int a;
float f;
String str;
double d;
boolean b;
char c;
short s;
byte b1;

public static void main(String [] args)
{
DataType d1=new DataType();
System.out.println("Integer value: "+d1.a);
System.out.println("float value: "+d1.f);
System.out.println("String value: "+d1.str);
System.out.println("double value: "+d1.d);

System.out.println("char value: "+d1.c);
System.out.println("boolean value: "+d1.b);
System.out.println("Short value: "+d1.s);
System.out.println("byte value: "+d1.b1);


}
}