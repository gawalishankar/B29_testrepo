# Impact18
java Code
